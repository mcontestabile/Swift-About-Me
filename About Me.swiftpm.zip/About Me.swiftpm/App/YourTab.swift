import SwiftUI

struct YourTab: View {
    var body: some View {
        VStack {
            Text("Hello, World!")
            Text("I'm trying to learn swift, hope to succeed.")
            Text("Send good vibes, thanks.")
        }
    }
}

struct YourTab_Previews: PreviewProvider {
    static var previews: some View {
        YourTab()
    }
}
